<?php
require_once '../includes/functions.php';

if (!isLoggedIn() || getUserRole() !== 'driver') {
    redirect('../login.php');
}

$user_id = $_SESSION['user_id'];

$rides = [];
$stmt = $conn->prepare("SELECT * FROM rides WHERE driver_id = ? ORDER BY departure_time DESC");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $rides[] = $row;
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Driver Dashboard - Carpool System</title>
    <style>
        :root {
            --primary-color: #3498db;
            --primary-hover: #2980b9;
            --danger-color: #e74c3c;
            --danger-hover: #c0392b;
            --success-color: #2ecc71;
            --text-color: #2c3e50;
            --light-gray: #f8f9fa;
            --border-color: #e0e0e0;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
            color: var(--text-color);
        }

        .navbar {
            background-color: white;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .navbar-brand {
            font-size: 20px;
            font-weight: 600;
            color: var(--primary-color);
            text-decoration: none;
        }

        .nav-links {
            display: flex;
            gap: 20px;
        }

        .nav-link {
            color: var(--text-color);
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s ease;
            padding: 5px 0;
            position: relative;
        }

        .nav-link:hover {
            color: var(--primary-color);
        }

        .nav-link.active {
            color: var(--primary-color);
        }

        .nav-link.active::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 2px;
            background-color: var(--primary-color);
        }

        .container {
            max-width: 1200px;
            margin: 30px auto;
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        h2 {
            color: var(--text-color);
            font-weight: 600;
            margin: 0;
        }

        h3 {
            color: var(--text-color);
            font-weight: 500;
            margin-top: 30px;
            margin-bottom: 20px;
        }

        .btn {
            background: var(--primary-color);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .btn:hover {
            background: var(--primary-hover);
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .btn-danger {
            background: var(--danger-color);
        }

        .btn-danger:hover {
            background: var(--danger-hover);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            font-size: 14px;
        }

        th,
        td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
        }

        th {
            background-color: var(--light-gray);
            font-weight: 600;
            color: var(--text-color);
        }

        tr:hover {
            background-color: rgba(52, 152, 219, 0.05);
        }

        .empty-state {
            text-align: center;
            padding: 40px;
            color: #7f8c8d;
        }

        .empty-state p {
            font-size: 16px;
            margin-bottom: 20px;
        }

        .status {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }

        .status.confirmed {
            background-color: rgba(46, 204, 113, 0.1);
            color: var(--success-color);
        }

        .status.pending {
            background-color: rgba(241, 196, 15, 0.1);
            color: #f1c40f;
        }

        .status.cancelled {
            background-color: rgba(231, 76, 60, 0.1);
            color: var(--danger-color);
        }
    </style>
</head>

<body>
    <nav class="navbar">
        <a href="dashboard.php" class="navbar-brand">Carpool System</a>
        <div class="nav-links">
            <a href="dashboard.php" class="nav-link active">Dashboard</a>
            <!--    <a href="view_rides.php" class="nav-link">Find Rides</a> -->
            <!--   <a href="my_bookings.php" class="nav-link">My Bookings</a> -->
            <a href="../logout.php" class="nav-link">Logout</a>
        </div>
    </nav>
    <div class="container">
        <div class="header">
            <h2>Driver Dashboard</h2>
            <a href="post_ride.php" class="btn btn-success">Post New Ride</a>
        </div>

        <h3>Your Posted Rides</h3>
        <?php if (empty($rides)): ?>
            <div class="empty-state">
                <p>You haven't posted any rides yet.</p>
                <a href="post_ride.php" class="btn btn-primary">Post Your First Ride</a>
            </div>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>Departure</th>
                        <th>Destination</th>
                        <th>Time</th>
                        <th>Seats</th>
                        <th>Price</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($rides as $ride): ?>
                        <tr>
                            <td><?= htmlspecialchars($ride['departure_location']) ?></td>
                            <td><?= htmlspecialchars($ride['destination']) ?></td>
                            <td><?= date('M j, Y g:i A', strtotime($ride['departure_time'])) ?></td>
                            <td><?= $ride['available_seats'] ?></td>
                            <td class="price">₱<?= number_format($ride['price'], 2) ?></td>
                            <td class="actions">
                                <a href="delete_ride.php?id=<?= $ride['id'] ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this ride?')">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</body>

</html>