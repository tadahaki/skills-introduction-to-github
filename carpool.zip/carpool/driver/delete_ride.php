<?php
require_once '../includes/functions.php';

if (!isLoggedIn() || getUserRole() !== 'driver') {
    redirect('../login.php');
}

if (!isset($_GET['id'])) {
    redirect('dashboard.php');
}

$ride_id = intval($_GET['id']);
$user_id = $_SESSION['user_id'];

$stmt = $conn->prepare("DELETE FROM rides WHERE id = ? AND driver_id = ?");
$stmt->bind_param("ii", $ride_id, $user_id);

if ($stmt->execute()) {
    $_SESSION['success'] = "Ride deleted successfully.";
} else {
    $_SESSION['error'] = "Failed to delete ride.";
}

redirect('dashboard.php');
