<?php
require_once '../includes/functions.php';

if (!isLoggedIn() || getUserRole() !== 'driver') {
    redirect('../login.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $departure = sanitizeInput($_POST['departure']);
    $destination = sanitizeInput($_POST['destination']);
    $departure_time = sanitizeInput($_POST['departure_time']);
    $seats = intval($_POST['seats']);
    $price = floatval($_POST['price']);
    $driver_id = $_SESSION['user_id'];

    $stmt = $conn->prepare("INSERT INTO rides (driver_id, departure_location, destination, departure_time, available_seats, price) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("isssid", $driver_id, $departure, $destination, $departure_time, $seats, $price);

    if ($stmt->execute()) {
        $_SESSION['success'] = "Ride posted successfully!";
        redirect('dashboard.php');
    } else {
        $error = "Failed to post ride. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Post a Ride - Carpool System</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" />
    <style>
        :root {
            --primary-color: #3498db;
            --primary-hover: #2980b9;
            --danger-color: #e74c3c;
            --danger-hover: #c0392b;
            --success-color: #2ecc71;
            --success-hover: #27ae60;
            --text-color: #2c3e50;
            --light-gray: #f8f9fa;
            --border-color: #e0e0e0;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
            color: var(--text-color);
        }

        .navbar {
            background-color: white;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .navbar-brand {
            font-size: 20px;
            font-weight: 600;
            color: var(--primary-color);
            text-decoration: none;
        }

        .nav-links {
            display: flex;
            gap: 20px;
        }

        .nav-link {
            color: var(--text-color);
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s ease;
            padding: 5px 0;
            position: relative;
        }

        .nav-link:hover {
            color: var(--primary-color);
        }

        .container {
            max-width: 600px;
            margin: 30px auto;
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
        }

        h2 {
            color: var(--text-color);
            font-weight: 600;
            text-align: center;
            margin-bottom: 30px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--text-color);
        }

        input[type="text"],
        input[type="datetime-local"],
        input[type="number"],
        select {
            width: 100%;
            padding: 12px;
            border: 1px solid var(--border-color);
            border-radius: 6px;
            font-family: inherit;
            font-size: 14px;
            transition: border-color 0.3s ease;
        }

        input[type="text"]:focus,
        input[type="datetime-local"]:focus,
        input[type="number"]:focus,
        select:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.1);
        }

        .btn {
            background: var(--success-color);
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 6px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
            width: 100%;
            text-align: center;
        }

        .btn:hover {
            background: var(--success-hover);
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .btn-secondary {
            background: #95a5a6;
            margin-top: 15px;
        }

        .btn-secondary:hover {
            background: #7f8c8d;
        }

        .error {
            color: var(--danger-color);
            margin-bottom: 20px;
            padding: 10px;
            background-color: rgba(231, 76, 60, 0.1);
            border-radius: 6px;
            text-align: center;
        }

        .form-footer {
            margin-top: 30px;
            text-align: center;
        }
    </style>
</head>

<body>
    <nav class="navbar">
        <a href="dashboard.php" class="navbar-brand">Carpool System</a>
        <div class="nav-links">
            <a href="dashboard.php" class="nav-link">Dashboard</a>
            <a href="../logout.php" class="nav-link">Logout</a>
        </div>
    </nav>

    <div class="container">
        <h2>Post a New Ride</h2>

        <?php if (isset($error)): ?>
            <div class="error"><?= $error ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label for="departure">Departure Location</label>
                <input type="text" id="departure" name="departure" required placeholder="e.g. Main Street, City Center">
            </div>

            <div class="form-group">
                <label for="destination">Destination</label>
                <input type="text" id="destination" name="destination" required placeholder="e.g. University Campus">
            </div>

            <div class="form-group">
                <label for="departure_time">Departure Time</label>
                <input type="datetime-local" id="departure_time" name="departure_time" required>
            </div>

            <div class="form-group">
                <label for="seats">Available Seats</label>
                <input type="number" id="seats" name="seats" min="1" required placeholder="Number of available seats">
            </div>

            <div class="form-group">
                <label for="price">Price per Seat (₱)</label>
                <input type="number" id="price" name="price" min="0" step="0.01" required placeholder="0.00">
            </div>

            <button type="submit" class="btn">Post Ride</button>
        </form>

        <div class="form-footer">
            <a href="dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
        </div>
    </div>
</body>

</html>