<?php
require_once 'config.php';

function sanitizeInput($data)
{
    global $conn;
    return htmlspecialchars(stripslashes(trim($conn->real_escape_string($data))));
}

function isLoggedIn()
{
    return isset($_SESSION['user_id']);
}

function redirect($url)
{
    header("Location: $url");
    exit();
}

function getUserRole()
{
    return $_SESSION['user_role'] ?? null;
}
