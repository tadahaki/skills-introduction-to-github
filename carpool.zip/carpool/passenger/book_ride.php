<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

if (!isLoggedIn() || getUserRole() !== 'passenger') {
    redirect('../login.php');
}

if (!isset($_GET['id'])) {
    redirect('view_rides.php');
}

$ride_id = intval($_GET['id']);
$passenger_id = $_SESSION['user_id'];

// Basic ride existence check (no time restriction)
$stmt = $conn->prepare("SELECT id, available_seats FROM rides WHERE id = ?");
$stmt->bind_param("i", $ride_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['error'] = "Ride not found.";
    redirect('view_rides.php');
}

$ride = $result->fetch_assoc();

// Check available seats
if ($ride['available_seats'] <= 0) {
    $_SESSION['error'] = "No available seats for this ride.";
    redirect('view_rides.php');
}

// Check for existing booking
$stmt = $conn->prepare("SELECT id FROM bookings WHERE ride_id = ? AND passenger_id = ? AND status = 'confirmed'");
$stmt->bind_param("ii", $ride_id, $passenger_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $_SESSION['error'] = "You have already booked this ride.";
    redirect('view_rides.php');
}

$stmt = $conn->prepare("INSERT INTO bookings (ride_id, passenger_id, status) VALUES (?, ?, 'confirmed')");
$stmt->bind_param("ii", $ride_id, $passenger_id);

if ($stmt->execute()) {
    // Update available seats
    $conn->query("UPDATE rides SET available_seats = available_seats - 1 WHERE id = $ride_id");
    $_SESSION['success'] = "Ride booked successfully!";
} else {
    $_SESSION['error'] = "Failed to book ride. Please try again.";
}

redirect('dashboard.php');
