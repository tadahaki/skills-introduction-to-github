<?php
require_once '../includes/functions.php';

if (!isLoggedIn() || getUserRole() !== 'passenger') {
    redirect('../login.php');
}

if (!isset($_GET['id'])) {
    redirect('dashboard.php');
}

$booking_id = intval($_GET['id']);
$passenger_id = $_SESSION['user_id'];

$stmt = $conn->prepare("SELECT id, ride_id FROM bookings WHERE id = ? AND passenger_id = ? AND status = 'confirmed'");
$stmt->bind_param("ii", $booking_id, $passenger_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['error'] = "Booking not found or already cancelled.";
    redirect('dashboard.php');
}

$booking = $result->fetch_assoc();
$ride_id = $booking['ride_id'];

$stmt = $conn->prepare("UPDATE bookings SET status = 'cancelled' WHERE id = ?");
$stmt->bind_param("i", $booking_id);

if ($stmt->execute()) {
    $conn->query("UPDATE rides SET available_seats = available_seats + 1 WHERE id = $ride_id");
    $_SESSION['success'] = "Booking cancelled successfully.";
} else {
    $_SESSION['error'] = "Failed to cancel booking. Please try again.";
}

redirect('dashboard.php');
