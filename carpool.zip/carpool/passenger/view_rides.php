<?php
require_once '../includes/functions.php';

if (!isLoggedIn() || getUserRole() !== 'passenger') {
    redirect('../login.php');
}
$success_message = $_SESSION['success'] ?? '';
$error_message = $_SESSION['error'] ?? '';
unset($_SESSION['success']);
unset($_SESSION['error']);

$departure = $_GET['departure'] ?? '';
$destination = $_GET['destination'] ?? '';
$date = $_GET['date'] ?? '';
$seats = $_GET['seats'] ?? '';

// Base SQL query
$sql = "SELECT r.*, u.username as driver_name 
        FROM rides r 
        JOIN users u ON r.driver_id = u.id 
        WHERE r.departure_time > ?";
$params = [date('Y-m-d H:i:s')];
$types = "s";

// Add search filters
if (!empty($departure)) {
    $sql .= " AND r.departure_location LIKE ?";
    $params[] = "%$departure%";
    $types .= "s";
}

if (!empty($destination)) {
    $sql .= " AND r.destination LIKE ?";
    $params[] = "%$destination%";
    $types .= "s";
}

if (!empty($date)) {
    $sql .= " AND DATE(r.departure_time) = ?";
    $params[] = $date;
    $types .= "s";
}

if (!empty($seats) && is_numeric($seats)) {
    $sql .= " AND r.available_seats >= ?";
    $params[] = $seats;
    $types .= "i";
}

// Order by soonest rides first
$sql .= " ORDER BY r.departure_time ASC";

// Prepare and execute query
$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

$rides = [];
while ($row = $result->fetch_assoc()) {
    $rides[] = $row;
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Available Rides - Carpool System</title>
    <style>
        :root {
            --primary-color: #3498db;
            --primary-hover: #2980b9;
            --success-color: #2ecc71;
            --success-hover: #27ae60;
            --text-color: #2c3e50;
            --light-gray: #f8f9fa;
            --border-color: #e0e0e0;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
            color: var(--text-color);
        }

        .navbar {
            background-color: white;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .navbar-brand {
            font-size: 20px;
            font-weight: 600;
            color: var(--primary-color);
            text-decoration: none;
        }

        .nav-links {
            display: flex;
            gap: 20px;
        }

        .nav-link {
            color: var(--text-color);
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s ease;
            padding: 5px 0;
            position: relative;
        }

        .nav-link:hover {
            color: var(--primary-color);
        }

        .nav-link.active {
            color: var(--primary-color);
        }

        .nav-link.active::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 2px;
            background-color: var(--primary-color);
        }

        .container {
            max-width: 1200px;
            margin: 30px auto;
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        h2 {
            color: var(--text-color);
            font-weight: 600;
            margin: 0;
        }

        .btn {
            background: var(--primary-color);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .btn:hover {
            background: var(--primary-hover);
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .btn-success {
            background: var(--success-color);
        }

        .btn-success:hover {
            background: var(--success-hover);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            font-size: 14px;
        }

        th,
        td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
        }

        th {
            background-color: var(--light-gray);
            font-weight: 600;
            color: var(--text-color);
        }

        tr:hover {
            background-color: rgba(52, 152, 219, 0.05);
        }

        .empty-state {
            text-align: center;
            padding: 40px;
            color: #7f8c8d;
        }

        .empty-state p {
            font-size: 16px;
            margin-bottom: 20px;
        }

        .price {
            font-weight: 600;
            color: var(--success-color);
        }

        .seats {
            font-weight: 500;
        }

        .seats.low {
            color: #e74c3c;
        }

        .seats.medium {
            color: #f39c12;
        }

        .seats.high {
            color: var(--success-color);
        }

        .search-filter {
            display: flex;
            gap: 15px;
            margin-bottom: 25px;
            flex-wrap: wrap;
        }

        .search-filter input,
        .search-filter select {
            padding: 10px 15px;
            border: 1px solid var(--border-color);
            border-radius: 6px;
            font-size: 14px;
            flex: 1;
            min-width: 150px;
        }

        .search-filter button {
            padding: 10px 20px;
        }

        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 6px;
            font-size: 14px;
            position: relative;
        }

        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .close-alert {
            position: absolute;
            right: 15px;
            top: 15px;
            cursor: pointer;
            font-weight: bold;
        }
    </style>
</head>

<body>
    <nav class="navbar">
        <a href="dashboard.php" class="navbar-brand">Carpool System</a>
        <div class="nav-links">
            <a href="dashboard.php" class="nav-link">Dashboard</a>
            <a href="view_rides.php" class="nav-link active">Find Rides</a>
            <a href="../logout.php" class="nav-link">Logout</a>
        </div>
    </nav>

    <div class="container">
        <?php if (!empty($success_message)): ?>
            <div class="alert alert-success">
                <?= htmlspecialchars($success_message) ?>
                <span class="close-alert" onclick="this.parentElement.style.display='none'">&times;</span>
            </div>
        <?php endif; ?>

        <?php if (!empty($error_message)): ?>
            <div class="alert alert-error">
                <?= htmlspecialchars($error_message) ?>
                <span class="close-alert" onclick="this.parentElement.style.display='none'">&times;</span>
            </div>
        <?php endif; ?>

        <div class="header">
            <h2>Available Rides</h2>
            <a href="dashboard.php" class="btn">Back to Dashboard</a>
        </div>

        <form method="GET" action="view_rides.php" class="search-filter">
            <input type="text" placeholder="From location" name="departure" value="<?= htmlspecialchars($departure) ?>">
            <input type="text" placeholder="To location" name="destination" value="<?= htmlspecialchars($destination) ?>">
            <input type="date" name="date" value="<?= htmlspecialchars($date) ?>">
            <select name="seats">
                <option value="">Seats needed</option>
                <option value="1" <?= $seats == '1' ? 'selected' : '' ?>>1 Seat</option>
                <option value="2" <?= $seats == '2' ? 'selected' : '' ?>>2 Seats</option>
                <option value="3" <?= $seats == '3' ? 'selected' : '' ?>>3+ Seats</option>
            </select>
            <button type="submit" class="btn">Search Rides</button>
        </form>

        <?php if (empty($rides)): ?>
            <div class="empty-state">
                <p>No available rides matching your criteria.</p>
                <a href="view_rides.php" class="btn">Reset Filters</a>
            </div>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>Driver</th>
                        <th>Departure → Destination</th>
                        <th>Date & Time</th>
                        <th>Seats</th>
                        <th>Price</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($rides as $ride):
                        $seatClass = '';
                        if ($ride['available_seats'] <= 1) {
                            $seatClass = 'low';
                        } elseif ($ride['available_seats'] <= 3) {
                            $seatClass = 'medium';
                        } else {
                            $seatClass = 'high';
                        }
                    ?>
                        <tr>
                            <td>
                                <strong><?= htmlspecialchars($ride['driver_name']) ?></strong><br>
                            </td>
                            <td>
                                <?= htmlspecialchars($ride['departure_location']) ?> →
                                <?= htmlspecialchars($ride['destination']) ?>
                            </td>
                            <td>
                                <?= date('D, M j', strtotime($ride['departure_time'])) ?><br>
                                <?= date('g:i A', strtotime($ride['departure_time'])) ?>
                            </td>
                            <td>
                                <span class="seats <?= $seatClass ?>">
                                    <?= $ride['available_seats'] ?> available
                                </span>
                            </td>
                            <td class="price">₱<?= number_format($ride['price'], 2) ?></td>
                            <td>
                                <a href="book_ride.php?id=<?= $ride['id'] ?>" class="btn btn-success">Book Now</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</body>

</html>